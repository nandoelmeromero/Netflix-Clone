**To update device status**

This example updates the status for a device to "not_remembered".

Command::

  aws cognito-idp update-device-status --access-token ACCESS_TOKEN --device-key DEVICE_KEY --device-remembered-status "not_remembered"
